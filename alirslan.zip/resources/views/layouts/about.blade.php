<!--Start call to action area-->
<section class="callto-action-area sec-padding">
    <div class="container">
        <div class="row">
            <div class="col-md-5 pull-right">
                <div class="img-holder wow slideInRight text-center">
                <img src="{{url('/public/web/template')}}/images/resources/callto-action.png" alt="Awesome Image">
                </div>
            </div> 
            <div class="col-md-7 pull-left">
                <div class="text-holder">
                    <div class="sec-title text-center">
                    {{-- <h3>{{__('السيره الذاتيه')}}</h3> --}}
                        <p>{!!$setting->word_ar!!} </p>
                     </div> 
                </div>
            </div> 
  
        </div>
    </div>
</section>
<!--End call to action area-->