<!-- /.container-fluid -->
<footer class="footer text-center"> 2020 &copy; All right reserved <a href="http://td.com.eg" target="_blank"> Typical Design </a> </footer>
