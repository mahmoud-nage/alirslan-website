<div id="failedModal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="margin-top:50px;">
    <div class="modal-dialog" style="margin-top:50px;">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <h4 class="modal-title" id="myModalLabel">{{ __('lang.failed') }}</h4> </div>
            <div class="modal-body">
                <p class="alert alert-danger">{{ __('lang.please_follow_instructions') }}</p>
                <p class="modal-alert-content"></p>
            </div>
            <div class="modal-footer">
              <ul class="">

              </ul>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
